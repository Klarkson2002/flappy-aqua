﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace game
{
    public partial class Form5 : Form
    {
        private Image birdImage;
        private Image pipeImage;
        private int birdY; // Вертикальная позиция птицы
        private int birdX = 50; // Горизонтальная позиция птицы
        private int gravity = 5; // Сила гравитации
        private int jumpHeight = 50; // Высота прыжка
        private Timer gameTimer;
        private bool isGameOver; // Флаг для определения состояния окончания игры
        private int[] pipeX = new int[2]; // Горизонтальные позиции труб
        private int[] pipeY = new int[2]; // Вертикальные позиции труб
        private int pipeSpeed = 5; // Скорость движения труб
        private int score = 0; // Счёт игрока
        private const int gapHeight = 250; // Высота зазора между трубами

        public Form5()
        {
            InitializeComponent();
            LoadImages();
            InitializeGame();
        }

        private void LoadImages()
        {
            // Загрузка изображений птицы и трубы из указанных путей
            try
            {
                birdImage = Image.FromFile(@"C:\Users\glnnn\OneDrive\Рабочий стол\4 курс\game\game\bin\bird.png");
                pipeImage = Image.FromFile(@"C:\Users\glnnn\OneDrive\Рабочий стол\4 курс\game\game\bin\pivo.png");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки изображений: " + ex.Message);
            }
        }

        private void InitializeGame()
        {
            birdY = this.ClientSize.Height / 2; // Начальная вертикальная позиция птицы
            pipeX[0] = this.ClientSize.Width + 100;
            pipeX[1] = this.ClientSize.Width + 600;
            pipeY[0] = new Random().Next(100, this.ClientSize.Height - gapHeight - 100); // Случайная вертикальная позиция для первой трубы
            pipeY[1] = pipeY[0] + gapHeight; // Установка позиции второй трубы ниже первой трубы
            gameTimer = new Timer();
            gameTimer.Interval = 20; // Интервал таймера в миллисекундах
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            this.KeyDown += Form5_KeyDown; // Обработка нажатий клавиш для прыжка
            isGameOver = false; // Инициализация состояния окончания игры
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (!isGameOver)
            {
                // Применение гравитации к вертикальной позиции птицы
                birdY += gravity;

                // Движение труб
                for (int i = 0; i < 2; i++)
                {
                    pipeX[i] -= pipeSpeed;

                    // Проверка, вышла ли труба за границы экрана
                    if (pipeX[i] < -50)
                    {
                        // Сброс позиции трубы и высоты
                        pipeX[i] = this.ClientSize.Width + 50;
                        pipeY[i] = new Random().Next(100, this.ClientSize.Height - gapHeight - 100); // Случайная вертикальная позиция для трубы
                        score++; // Увеличение счёта, когда труба уходит за экран
                    }
                }

                // Проверка на столкновение с верхними или нижними границами
                if (birdY < 0 || birdY > this.ClientSize.Height - birdImage.Height)
                {
                    GameOver();
                }

                // Проверка на столкновение с трубами
                for (int i = 0; i < 2; i++)
                {
                    if (IsColliding(birdX, birdY, birdImage.Width, birdImage.Height, pipeX[i], pipeY[i], pipeImage.Width, pipeY[i] + gapHeight))
                    {
                        GameOver();
                    }
                }

                // Перерисовка формы для отображения птицы и труб
                this.Invalidate();
            }
        }

        private bool IsColliding(int birdX, int birdY, int birdWidth, int birdHeight, int pipeX, int pipeY, int pipeWidth, int pipeHeight)
        {
            // Проверка на столкновение между птицей и трубой
            return birdX + birdWidth > pipeX && birdX < pipeX + pipeWidth &&
                   (birdY < pipeY || birdY + birdHeight > pipeY + gapHeight); // Проверка, находится ли птица выше или ниже зазора
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // Рисование изображения птицы в текущей позиции
            e.Graphics.DrawImage(birdImage, new Rectangle(birdX, birdY, birdImage.Width, birdImage.Height));

            // Рисование труб
            for (int i = 0; i < 2; i++)
            {
                // Рисование верхней части трубы
                e.Graphics.DrawImage(pipeImage, new Rectangle(pipeX[i], 0, pipeImage.Width, pipeY[i]));
                // Рисование нижней части трубы
                e.Graphics.DrawImage(pipeImage, new Rectangle(pipeX[i], pipeY[i] + gapHeight, pipeImage.Width, this.ClientSize.Height - pipeY[i] - gapHeight));
            }

            // Рисование счёта
            e.Graphics.DrawString("Счёт: " + score, new Font("Arial", 16), Brushes.White, 10, 10);
        }

        private void Form5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && !isGameOver) // Прыжок при нажатии пробела и если игра не окончена
            {
                birdY -= jumpHeight; // Перемещение птицы вверх
            }
        }

        private void GameOver()
        {
            isGameOver = true; // Установка состояния окончания игры
            gameTimer.Stop(); // Остановка таймера игры
            DialogResult result = MessageBox.Show("Игра окончена! Ваш счёт: " + score + ". Нажмите OK для перезапуска или Отмена для выхода.", "Игра окончена", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                RestartGame();
            }
            else if (result == DialogResult.Cancel)
            {
                this.Hide(); // Скрыть текущую форму
                Form1 form1 = new Form1(); // Создать новый экземпляр Form1
                form1.Show(); // Показать Form1
            }
        }

        private void RestartGame()
        {
            birdY = this.ClientSize.Height / 2; // Сброс позиции птицы
            pipeX[0] = this.ClientSize.Width + 100;
            pipeX[1] = this.ClientSize.Width + 600;
            pipeY[0] = new Random().Next(100, this.ClientSize.Height - gapHeight - 100); // Случайная вертикальная позиция для первой трубы
            pipeY[1] = pipeY[0] + gapHeight; // Установка позиции второй трубы ниже первой трубы
            score = 0; // Сброс счёта
            isGameOver = false; // Сброс состояния окончания игры
            gameTimer.Start(); // Перезапуск таймера
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // Дополнительная инициализация при загрузке формы
        }
    }
}